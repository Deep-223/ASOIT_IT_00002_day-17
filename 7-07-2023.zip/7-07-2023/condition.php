<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $t=30;
    $favcolor = "green";
    echo "enter the value=", $t ;
    echo "<br>";
    if ($t<"20") {
        echo "have a good day ";
    } else{
        echo "have a good night";
        echo "<br>";
    }
switch ($favcolor) {
  case "red":
    echo "Your favorite color is red!";
    break;
  case "blue":
    echo "Your favorite color is blue!";
    break;
  case "green":
    echo "Your favorite color is green!";
    break;
  default:
    echo "Your favorite color is neither red, blue, nor green!";
}

    ?>
</body>
</html>